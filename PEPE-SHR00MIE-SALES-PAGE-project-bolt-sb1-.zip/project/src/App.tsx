import React from 'react';
import { TokenSale } from './components/TokenSale';

function App() {
  return (
    <div className="min-h-screen bg-gray-900">
      <TokenSale />
    </div>
  );
}

export default App;