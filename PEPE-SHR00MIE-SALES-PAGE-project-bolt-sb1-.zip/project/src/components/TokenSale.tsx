import { FC, useState, useEffect } from 'react';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletMultiButton } from '@solana/wallet-adapter-react-ui';
import { Coins, ExternalLink, Timer, Wallet, Users, Award, Copy, ChevronRight } from 'lucide-react';
import { formatDistanceToNow, addWeeks } from 'date-fns';

const TOKEN_PRICE = 0.0081;
const MIN_BUY = 10;
const MAX_BUY = 1000;
const TOTAL_SUPPLY = 300000000;
const SOFT_CAP = 500000;
const HARD_CAP = 2430000;
const CONTRACT_ADDRESS = 'YOUR_CONTRACT_ADDRESS';

interface ReferralStats {
  totalReferrals: number;
  directReferrals: number;
  indirectReferrals: number;
  earnedRewards: number;
}

interface TopReferrer {
  address: string;
  referrals: number;
  rewards: number;
}

export const TokenSale: FC = () => {
  const { connected, publicKey } = useWallet();
  const [solAmount, setSolAmount] = useState('');
  const [tokenAmount, setTokenAmount] = useState(0);
  const [soldTokens, setSoldTokens] = useState(56000000);
  const [timeLeft, setTimeLeft] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [referralStats, setReferralStats] = useState<ReferralStats>({
    totalReferrals: 0,
    directReferrals: 0,
    indirectReferrals: 0,
    earnedRewards: 0,
  });
  const [topReferrers, setTopReferrers] = useState<TopReferrer[]>([
    { address: '7xKX...9Yka', referrals: 25, rewards: 12.5 },
    { address: '3mNR...4Pqb', referrals: 18, rewards: 9.0 },
    { address: '9vWZ...2Htc', referrals: 15, rewards: 7.5 },
  ]);

  const referralLink = publicKey 
    ? `https://www.pepeshr00mie.com/?ref=${publicKey.toString()}`
    : '';

  useEffect(() => {
    const timer = setInterval(() => {
      const startDate = addWeeks(new Date(), 1); // Sale starts in 1 week
      setTimeLeft(formatDistanceToNow(startDate, { addSuffix: true }));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleSolInputChange = (value: string) => {
    setSolAmount(value);
    setTokenAmount(Number(value) / TOKEN_PRICE);
  };

  const copyReferralLink = async () => {
    if (referralLink) {
      await navigator.clipboard.writeText(referralLink);
    }
  };

  const progress = (soldTokens / TOTAL_SUPPLY) * 100;

  const handlePurchase = async () => {
    if (!connected || isProcessing) return;
    setIsProcessing(true);
    setTimeout(() => setIsProcessing(false), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://static.wixstatic.com/media/a00646_b30a5fe6680c43a4992b824442502c5b~mv2.jpeg/v1/fill/w_1600,h_687,al_c,q_85,usm_4.00_1.00_0.00,enc_avif,quality_auto/a00646_b30a5fe6680c43a4992b824442502c5b~mv2.jpeg')`
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900/80 via-gray-900/70 to-gray-900" />
        <div className="relative max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl font-extrabold tracking-tight mb-4 bg-gradient-to-r from-green-400 to-blue-500 bg-clip-text text-transparent">
              Join the $SHR00MIE Pre-Sale!
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Get in early and secure your $SHR00MIE before the public sale.
            </p>
            <div className="flex justify-center mb-12">
              <WalletMultiButton className="!bg-blue-600 hover:!bg-blue-700 transition-colors duration-200" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 max-w-5xl mx-auto">
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700/50">
                <Timer className="w-8 h-8 mb-4 mx-auto text-green-400" />
                <p className="text-sm text-gray-400">Sale Starts</p>
                <p className="text-lg font-semibold">{timeLeft}</p>
              </div>
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700/50">
                <Coins className="w-8 h-8 mb-4 mx-auto text-green-400" />
                <p className="text-sm text-gray-400">Tokens Sold</p>
                <p className="text-lg font-semibold">{soldTokens.toLocaleString()} SHR00MIE</p>
              </div>
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700/50">
                <Wallet className="w-8 h-8 mb-4 mx-auto text-green-400" />
                <p className="text-sm text-gray-400">Price per Token</p>
                <p className="text-lg font-semibold">${TOKEN_PRICE}</p>
              </div>
              <div className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700/50">
                <Users className="w-8 h-8 mb-4 mx-auto text-green-400" />
                <p className="text-sm text-gray-400">Available Supply</p>
                <p className="text-lg font-semibold">{TOTAL_SUPPLY.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-16 grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Buy Form */}
        <div className="lg:col-span-2">
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
            <h2 className="text-2xl font-bold mb-6">Buy Tokens</h2>
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Enter Amount (USD)
                </label>
                <input
                  type="number"
                  value={solAmount}
                  onChange={(e) => handleSolInputChange(e.target.value)}
                  min={MIN_BUY}
                  max={MAX_BUY}
                  className="w-full bg-gray-700 rounded-lg px-4 py-2 text-white border border-gray-600 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-colors"
                  placeholder="Enter amount..."
                />
                <div className="mt-2 flex justify-between text-sm text-gray-400">
                  <span>Min: ${MIN_BUY}</span>
                  <span>Max: ${MAX_BUY}</span>
                </div>
                <p className="mt-2 text-sm text-gray-400">
                  You will receive: {tokenAmount.toLocaleString()} SHR00MIE
                </p>
              </div>
              <button
                onClick={handlePurchase}
                disabled={!connected || isProcessing}
                className="w-full bg-gradient-to-r from-blue-600 to-green-500 hover:from-blue-700 hover:to-green-600 disabled:from-gray-600 disabled:to-gray-700 rounded-lg px-4 py-3 font-medium transition-all duration-200 relative overflow-hidden"
              >
                {isProcessing ? (
                  <span className="flex items-center justify-center">
                    <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Processing...
                  </span>
                ) : connected ? 'Buy Now' : 'Connect Wallet to Buy'}
              </button>
            </div>

            {/* Caps Information */}
            <div className="mt-6 grid grid-cols-2 gap-4">
              <div className="bg-gray-700/50 rounded-lg p-4">
                <p className="text-sm text-gray-400">Soft Cap</p>
                <p className="text-xl font-semibold">${SOFT_CAP.toLocaleString()}</p>
              </div>
              <div className="bg-gray-700/50 rounded-lg p-4">
                <p className="text-sm text-gray-400">Hard Cap</p>
                <p className="text-xl font-semibold">${HARD_CAP.toLocaleString()}</p>
              </div>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mt-8">
            <div className="flex justify-between text-sm mb-2">
              <span>Sale Progress</span>
              <span>{progress.toFixed(1)}%</span>
            </div>
            <div className="h-4 bg-gray-700 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-blue-600 to-green-500 transition-all duration-500"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        {/* Referral System */}
        <div className="lg:col-span-1">
          <div className="bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Award className="w-6 h-6 text-green-400" />
              Referral Program
            </h2>
            {connected ? (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Your Referral Link
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={referralLink}
                      readOnly
                      className="w-full bg-gray-700 rounded-lg px-4 py-2 text-sm text-gray-300"
                    />
                    <button
                      onClick={copyReferralLink}
                      className="bg-blue-600 hover:bg-blue-700 rounded-lg p-2 transition-colors"
                    >
                      <Copy className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-700/50 rounded-lg p-4">
                    <p className="text-sm text-gray-400">Direct Referrals</p>
                    <p className="text-xl font-semibold">{referralStats.directReferrals}</p>
                  </div>
                  <div className="bg-gray-700/50 rounded-lg p-4">
                    <p className="text-sm text-gray-400">Indirect Referrals</p>
                    <p className="text-xl font-semibold">{referralStats.indirectReferrals}</p>
                  </div>
                </div>
                <div className="bg-gray-700/50 rounded-lg p-4">
                  <p className="text-sm text-gray-400">Total Earned Rewards</p>
                  <p className="text-xl font-semibold">{referralStats.earnedRewards} SOL</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-400 mb-4">Connect your wallet to get your referral link and start earning rewards!</p>
                <WalletMultiButton className="!bg-blue-600 hover:!bg-blue-700" />
              </div>
            )}
          </div>

          {/* Top Referrers */}
          <div className="mt-8 bg-gray-800/50 backdrop-blur-sm rounded-2xl p-8 border border-gray-700/50">
            <h3 className="text-xl font-bold mb-4">Top Referrers</h3>
            <div className="space-y-4">
              {topReferrers.map((referrer, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-gray-700/50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center ${
                      index === 0 ? 'bg-yellow-500' :
                      index === 1 ? 'bg-gray-400' :
                      'bg-bronze-500'
                    }`}>
                      {index + 1}
                    </div>
                    <span className="text-sm">{referrer.address}</span>
                  </div>
                  <span className="text-sm font-medium">{referrer.rewards} SOL</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* How It Works */}
      <div className="max-w-7xl mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-12 text-center">How It Works</h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
          {[
            { title: 'Connect Wallet', desc: 'Connect your Solana wallet (Phantom, Solflare, etc.)', icon: Wallet },
            { title: 'Enter Amount', desc: 'Specify how much you want to invest', icon: Coins },
            { title: 'Confirm Transaction', desc: 'Approve the transaction in your wallet', icon: ChevronRight },
            { title: 'Receive Tokens', desc: 'Get your SHR00MIE tokens after the pre-mint', icon: Award },
            { title: 'Share & Earn', desc: 'Share your referral link to earn rewards', icon: Users }
          ].map((step, i) => (
            <div key={i} className="bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700/50">
              <div className="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mb-4">
                <step.icon className="w-6 h-6" />
              </div>
              <h3 className="font-medium mb-2">{step.title}</h3>
              <p className="text-gray-400 text-sm">{step.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Contract Info */}
      <div className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h3 className="text-2xl font-bold mb-8">Smart Contract Details</h3>
        <div className="inline-block bg-gray-800/50 backdrop-blur-sm rounded-lg p-6 border border-gray-700/50">
          <p className="text-sm text-gray-400 mb-2">Verified Smart Contract Address</p>
          <div className="flex items-center justify-center gap-4">
            <code className="bg-gray-700 px-4 py-2 rounded text-sm">{CONTRACT_ADDRESS}</code>
            <a
              href={`https://solscan.io/address/${CONTRACT_ADDRESS}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
            >
              <ExternalLink className="w-4 h-4" />
              View on Solscan
            </a>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-gray-800/50 mt-24">
        <div className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
          <div className="text-center">
            <h3 className="text-xl font-semibold mb-4">Join the $SHR00MIE Community</h3>
            <div className="flex justify-center gap-6">
              <a
                href="https://t.me/PEPECHOCOSHR00MIE"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                Telegram
              </a>
              <a
                href="https://x.com/PepeShr00mie"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                Twitter
              </a>
              <a
                href="https://www.pepeshr00mie.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gray-400 hover:text-white transition-colors"
              >
                Website
              </a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};